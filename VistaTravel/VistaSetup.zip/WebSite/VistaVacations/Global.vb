Imports System
Imports System.Collections
Imports System.Core
Imports System.ComponentModel
Imports System.Web
Imports System.Web.SessionState

Namespace VistaVacations

	Public Class Global
		Inherits System.Web.HttpApplication

		Sub Application_Start(ByVal Sender As Object, ByVal e As EventArgs)

		End Sub

		Sub Session_Start(ByVal Sender As Object, ByVal e As EventArgs)

		End Sub

		Sub Application_BeginRequest(ByVal Sender As Object, ByVal e As EventArgs)

		End Sub

		Sub Application_EndRequest(ByVal Sender As Object, ByVal e As EventArgs)

		End Sub

		Sub Session_End(ByVal Sender As Object, ByVal e As EventArgs)

		End Sub

		Sub Application_End(ByVal Sender As Object, ByVal e As EventArgs)

		End Sub

	End Class

End Namespace

