To start the installation open the Install.htm in the 
current directory in an Internet Explorer web browser 
and follow the directions.