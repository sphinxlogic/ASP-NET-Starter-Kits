Namespace CreditCardMgr
    Public Class CheckCredit

        Public Function IsCardValid(ByVal FName As String, ByVal LName As String, ByVal CardType As String, ByVal CardNum As Long, ByVal ExpDate As Date) As Boolean

            Return True

        End Function

    End Class
End Namespace
